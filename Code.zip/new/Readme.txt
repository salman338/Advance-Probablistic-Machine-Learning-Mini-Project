Version : Python 3.8.5
Required Packages : numpy, panda, math, matlibplot

Run the Runme.ipynb